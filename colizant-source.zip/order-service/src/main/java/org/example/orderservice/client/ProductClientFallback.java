package org.example.orderservice.client;

import org.example.orderservice.dto.ComponentDto;
import org.springframework.stereotype.Component;

@Component
public class ProductClientFallback implements ProductClient {
    @Override
    public ComponentDto getComponentById(Long id) {
        // Бросаем ошибку, чтобы OrderController понял, что товара нет
        throw new RuntimeException("Товар не найден");
    }

    @Override
    public void decreaseStock(Long id, Integer quantity) {
        // Бросаем ошибку, если не удалось списать (нет на складе)
        throw new RuntimeException("Недостаточно товара на складе");
    }
}