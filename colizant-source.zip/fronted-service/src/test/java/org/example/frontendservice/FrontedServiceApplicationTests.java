package org.example.frontendservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontedServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
