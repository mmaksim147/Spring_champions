package org.example.frontendservice.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/admin/users")
public class AdminUserController {

    private final RestTemplate restTemplate;
    @Value("${gateway.url}")
    private String gatewayUrl;

    public AdminUserController(RestTemplate restTemplate) { this.restTemplate = restTemplate; }

    @GetMapping
    public String list(HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) return "redirect:/login";
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);
            ResponseEntity<List> response = restTemplate.exchange(
                    gatewayUrl + "/api/admin/users", HttpMethod.GET, new HttpEntity<>(headers), List.class);
            model.addAttribute("users", response.getBody());
        } catch (Exception e) {
            model.addAttribute("error", "Ошибка загрузки");
        }
        return "admin/users";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id, HttpSession session) {
        String token = (String) session.getAttribute("token");
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);
            restTemplate.exchange(gatewayUrl + "/api/admin/users/" + id, HttpMethod.DELETE, new HttpEntity<>(headers), Void.class);
        } catch (Exception ignored) {}
        return "redirect:/admin/users";
    }

    @PostMapping("/role/{id}")
    public String changeRole(@PathVariable Long id, @RequestParam String role, HttpSession session) {
        String token = (String) session.getAttribute("token");
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);
            headers.setContentType(MediaType.APPLICATION_JSON);
            String fullRole = role.startsWith("ROLE_") ? role : "ROLE_" + role;
            Map<String, Object> body = Map.of("roles", List.of(fullRole));
            restTemplate.exchange(gatewayUrl + "/api/admin/users/" + id + "/roles", HttpMethod.PUT, new HttpEntity<>(body, headers), Void.class);
        } catch (Exception ignored) {}
        return "redirect:/admin/users";
    }
}