package org.example.frontendservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrontedServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(FrontedServiceApplication.class, args);
    }

}
