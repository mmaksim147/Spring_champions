package org.example.frontendservice.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Controller
@RequestMapping("/admin/components")
public class AdminComponentController {

    private final RestTemplate restTemplate;
    @Value("${gateway.url}")
    private String gatewayUrl;

    public AdminComponentController(RestTemplate restTemplate) { this.restTemplate = restTemplate; }

    @GetMapping
    public String list(@RequestParam(defaultValue = "0") int page,
                       @RequestParam(defaultValue = "10") int size,
                       @RequestParam(required = false) String search,
                       HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) return "redirect:/login";
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);

            String url = gatewayUrl + "/api/components?page=" + page + "&size=" + size;
            if (search != null && !search.isEmpty()) url += "&search=" + search;

            ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(headers), Map.class);

            if (response.getBody() != null) {
                model.addAttribute("components", response.getBody().get("content"));
                model.addAttribute("totalPages", ((Number) response.getBody().get("totalPages")).intValue());
                model.addAttribute("currentPage", page);
            }
            model.addAttribute("search", search);
        } catch (Exception e) {
            model.addAttribute("error", "Ошибка загрузки: " + e.getMessage());
        }
        return "admin/components";
    }

    @PostMapping("/create")
    public String create(@RequestParam String name,
                         @RequestParam String manufacturer,
                         @RequestParam java.math.BigDecimal price,
                         @RequestParam Integer stockQuantity,
                         HttpSession session) {
        String token = (String) session.getAttribute("token");
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, Object> body = Map.of(
                    "name", name,
                    "manufacturer", manufacturer,
                    "price", price,
                    "stockQuantity", stockQuantity,
                    "category", Map.of("id", 1) // Пока оставляем 1, так как форма не запрашивает категорию
            );
            restTemplate.postForEntity(gatewayUrl + "/api/components", new HttpEntity<>(body, headers), Void.class);
        } catch (Exception e) {
            return "redirect:/admin/components?error=" + e.getMessage();
        }
        return "redirect:/admin/components?success";
    }

    @PostMapping("/update")
    public String update(@RequestParam Long id,
                         @RequestParam String name,
                         @RequestParam String manufacturer,
                         @RequestParam java.math.BigDecimal price,
                         @RequestParam Integer stockQuantity,
                         HttpSession session) {
        String token = (String) session.getAttribute("token");
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, Object> body = Map.of(
                    "name", name,
                    "manufacturer", manufacturer,
                    "price", price,
                    "stockQuantity", stockQuantity
            );
            restTemplate.exchange(gatewayUrl + "/api/components/" + id, HttpMethod.PUT, new HttpEntity<>(body, headers), Void.class);
        } catch (Exception e) {
            return "redirect:/admin/components?error=" + e.getMessage();
        }
        return "redirect:/admin/components?success";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id, HttpSession session) {
        String token = (String) session.getAttribute("token");
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);
            restTemplate.exchange(gatewayUrl + "/api/components/" + id, HttpMethod.DELETE, new HttpEntity<>(headers), Void.class);
        } catch (Exception e) {
            return "redirect:/admin/components?error=" + e.getMessage();
        }
        return "redirect:/admin/components?success";
    }
}