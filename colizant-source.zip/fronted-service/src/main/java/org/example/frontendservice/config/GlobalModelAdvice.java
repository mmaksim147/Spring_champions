package org.example.frontendservice.config;

import jakarta.servlet.http.HttpSession;
import org.example.frontendservice.dto.CartDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.client.RestTemplate;

@ControllerAdvice
public class GlobalModelAdvice {

    private final RestTemplate restTemplate;
    @Value("${gateway.url}")
    private String gatewayUrl;

    public GlobalModelAdvice(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @ModelAttribute
    public void addGlobalAttributes(HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        if (token != null) {
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.set("Authorization", "Bearer " + token);

                // Достаем userId из сессии (если есть), или из JWT
                Long userId = (Long) session.getAttribute("userId");
                if (userId == null) userId = 1L; // Fallback

                ResponseEntity<CartDto> response = restTemplate.exchange(
                        gatewayUrl + "/api/cart/" + userId,
                        HttpMethod.GET, new HttpEntity<>(headers), CartDto.class);

                if (response.getBody() != null && response.getBody().getItems() != null) {
                    model.addAttribute("cartCount", response.getBody().getItems().size());
                } else {
                    model.addAttribute("cartCount", 0);
                }
            } catch (Exception e) {
                model.addAttribute("cartCount", 0);
            }
        } else {
            model.addAttribute("cartCount", 0);
        }
    }
}