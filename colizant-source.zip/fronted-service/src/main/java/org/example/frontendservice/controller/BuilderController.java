package org.example.frontendservice.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import jakarta.servlet.http.HttpSession;
import org.example.frontendservice.dto.ProductDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriUtils;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Controller
public class BuilderController {

    private static final Logger log =
            LoggerFactory.getLogger(BuilderController.class);

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    @Value("${gateway.url}")
    private String gatewayUrl;

    public BuilderController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }

    @GetMapping("/builder")
    public String builderPage(HttpSession session, Model model) {

        String token = (String) session.getAttribute("token");

        if (token == null) {
            return "redirect:/login";
        }

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(token);

            ResponseEntity<Map> response = restTemplate.exchange(
                    gatewayUrl + "/api/components?size=100",
                    HttpMethod.GET,
                    new HttpEntity<>(headers),
                    Map.class
            );

            List<ProductDto> components = new ArrayList<>();

            if (response.getBody() != null) {
                Object content = response.getBody().get("content");

                if (content instanceof List<?> items) {
                    components = items.stream()
                            .map(item -> objectMapper.convertValue(
                                    item, ProductDto.class))
                            .toList();
                }
            }

            model.addAttribute("components", components);
            model.addAttribute("username",
                    session.getAttribute("username"));

        } catch (RestClientResponseException e) {
            log.error("Backend returned {} while loading components",
                    e.getStatusCode());

            model.addAttribute("components", List.of());
            model.addAttribute("error",
                    "Не удалось загрузить комплектующие. Попробуйте позже.");

        } catch (Exception e) {
            log.error("Error loading builder components", e);

            model.addAttribute("components", List.of());
            model.addAttribute("error",
                    "Ошибка загрузки комплектующих.");
        }

        return "builder";
    }

    @PostMapping("/builder/save")
    public String saveBuild(
            @RequestParam String name,
            @RequestParam List<Long> componentId,
            @RequestParam List<Integer> quantity,
            HttpSession session) {

        String token = (String) session.getAttribute("token");

        if (token == null) {
            return "redirect:/login";
        }

        if (name == null || name.isBlank()
                || componentId == null || componentId.isEmpty()
                || quantity == null
                || componentId.size() != quantity.size()) {

            return "redirect:/builder?error=invalid";
        }

        for (int i = 0; i < componentId.size(); i++) {
            if (componentId.get(i) == null
                    || componentId.get(i) <= 0
                    || quantity.get(i) == null
                    || quantity.get(i) < 1
                    || quantity.get(i) > 99) {

                return "redirect:/builder?error=invalid";
            }
        }

        try {
            Long userId = extractUserIdFromToken(token);

            if (userId == null) {
                return "redirect:/builder?error=user";
            }

            List<Map<String, Object>> items = new ArrayList<>();

            for (int i = 0; i < componentId.size(); i++) {

                Map<String, Object> item = new LinkedHashMap<>();

                item.put("componentId", componentId.get(i));
                item.put("quantity", quantity.get(i));

                items.add(item);
            }

            Map<String, Object> buildRequest = new LinkedHashMap<>();

            buildRequest.put("userId", userId);
            buildRequest.put("name", name.trim());
            buildRequest.put("items", items);

            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(token);
            headers.setContentType(MediaType.APPLICATION_JSON);

            restTemplate.exchange(
                    gatewayUrl + "/api/builds",
                    HttpMethod.POST,
                    new HttpEntity<>(buildRequest, headers),
                    Void.class
            );

            return "redirect:/builds?success";

        } catch (RestClientResponseException e) {

            log.error("Backend rejected build creation: {}",
                    e.getStatusCode());

            return "redirect:/builder?error=backend";

        } catch (Exception e) {

            log.error("Error saving PC build", e);

            return "redirect:/builder?error=save";
        }
    }

    private Long extractUserIdFromToken(String token) {

        try {
            String[] parts = token.split("\\.");

            if (parts.length < 2) {
                return null;
            }

            byte[] decoded = java.util.Base64
                    .getUrlDecoder()
                    .decode(parts[1]);

            JsonNode payload = objectMapper.readTree(decoded);
            JsonNode userIdNode = payload.get("userId");

            if (userIdNode == null || userIdNode.isNull()) {
                return null;
            }

            if (userIdNode.canConvertToLong()) {
                return userIdNode.asLong();
            }

            return null;

        } catch (Exception e) {
            log.warn("Cannot extract userId from JWT");
            return null;
        }
    }
}