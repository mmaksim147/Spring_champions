package org.example.frontendservice.controller;

import jakarta.servlet.http.HttpSession;
import org.example.frontendservice.dto.CategoryDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Map;

@Controller
@RequestMapping("/admin/categories")
public class AdminCategoryController {

    private final RestTemplate restTemplate;
    @Value("${gateway.url}")
    private String gatewayUrl;

    public AdminCategoryController(RestTemplate restTemplate) { this.restTemplate = restTemplate; }

    @GetMapping
    public String list(HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) return "redirect:/login";
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);
            ResponseEntity<CategoryDto[]> response = restTemplate.exchange(
                    gatewayUrl + "/api/categories", HttpMethod.GET, new HttpEntity<>(headers), CategoryDto[].class);
            model.addAttribute("categories", Arrays.asList(response.getBody()));
        } catch (Exception e) {
            model.addAttribute("error", "Ошибка загрузки");
        }
        return "admin/categories";
    }

    @PostMapping("/create")
    public String create(@RequestParam String name, HttpSession session) {
        String token = (String) session.getAttribute("token");
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);
            headers.setContentType(MediaType.APPLICATION_JSON);
            restTemplate.postForEntity(gatewayUrl + "/api/categories", new HttpEntity<>(Map.of("name", name), headers), Void.class);
        } catch (Exception ignored) {}
        return "redirect:/admin/categories";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id, HttpSession session) {
        String token = (String) session.getAttribute("token");
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);
            restTemplate.exchange(gatewayUrl + "/api/categories/" + id, HttpMethod.DELETE, new HttpEntity<>(headers), Void.class);
        } catch (Exception ignored) {}
        return "redirect:/admin/categories";
    }
}