
package org.example.frontendservice.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Controller
public class AdminController {

    private final RestTemplate restTemplate;

    @Value("${gateway.url}")
    private String gatewayUrl;

    public AdminController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    // Проверка администратора
    private boolean isAdmin(HttpSession session) {
        String token = (String) session.getAttribute("token");
        Object roles = session.getAttribute("roles");

        return token != null
                && roles != null
                && roles.toString().contains("ROLE_ADMIN");
    }

    private HttpEntity<Void> getHeaders(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);

        return new HttpEntity<>(headers);
    }

    // Главная страница
    @GetMapping("/admin")
    public String adminPage(HttpSession session) {

        if (session.getAttribute("token") == null) {
            return "redirect:/login";
        }

        if (!isAdmin(session)) {
            return "redirect:/catalog";
        }

        return "admin/index";
    }

    // Удаление пользователя
    @PostMapping({
            "/admin/users/delete/{id}",
            "/admin/users/{id}/delete"
    })
    public String deleteUser(
            @PathVariable Long id,
            HttpSession session) {

        if (!isAdmin(session)) {
            return "redirect:/login";
        }

        try {
            String token = (String) session.getAttribute("token");

            restTemplate.exchange(
                    gatewayUrl + "/api/admin/users/" + id,
                    HttpMethod.DELETE,
                    getHeaders(token),
                    Void.class
            );

            return "redirect:/admin/users?success";

        } catch (Exception e) {
            return "redirect:/admin/users?error";
        }
    }

    // Изменение роли пользователя
    @PostMapping({
            "/admin/users/role/{id}",
            "/admin/users/{id}/role"
    })
    public String changeRole(
            @PathVariable Long id,
            @RequestParam String role,
            HttpSession session) {

        if (!isAdmin(session)) {
            return "redirect:/login";
        }

        try {
            String token = (String) session.getAttribute("token");

            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(token);
            headers.setContentType(MediaType.APPLICATION_JSON);

            String fullRole = role.startsWith("ROLE_")
                    ? role
                    : "ROLE_" + role;

            Map<String, Object> body = Map.of(
                    "roles", List.of(fullRole)
            );

            restTemplate.exchange(
                    gatewayUrl + "/api/admin/users/" + id + "/roles",
                    HttpMethod.PUT,
                    new HttpEntity<>(body, headers),
                    Void.class
            );

            return "redirect:/admin/users?success";

        } catch (Exception e) {
            return "redirect:/admin/users?error";
        }
    }
}
