package org.example.frontendservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpSession;
import org.example.frontendservice.dto.ProductDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
public class CatalogController {

    private final RestTemplate restTemplate;

    @Value("${gateway.url}")
    private String gatewayUrl;

    public CatalogController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping("/catalog")
    public String catalog(HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) return "redirect:/login";

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);

            // Запрашиваем компоненты (с параметром size=100, чтобы получить все)
            ResponseEntity<Map> response = restTemplate.exchange(
                    gatewayUrl + "/api/components?size=100",
                    HttpMethod.GET,
                    new HttpEntity<>(headers),
                    Map.class
            );

            List<ProductDto> products = new ArrayList<>();
            if (response.getBody() != null && response.getBody().containsKey("content")) {
                // Достаем список из поля content
                List<Map<String, Object>> content = (List<Map<String, Object>>) response.getBody().get("content");
                ObjectMapper mapper = new ObjectMapper();
                mapper.registerModule(new com.fasterxml.jackson.datatype.jsr310.JavaTimeModule()); // <--- ВОТ ЭТО
                for (Map<String, Object> item : content) {
                    products.add(mapper.convertValue(item, ProductDto.class));
                }
            }

            model.addAttribute("products", products);
            model.addAttribute("username", session.getAttribute("username"));

            Object roles = session.getAttribute("roles");
            model.addAttribute("isAdmin", roles != null && roles.toString().contains("ROLE_ADMIN"));

        } catch (Exception e) {
            e.printStackTrace(); // Чтобы видеть ошибку в консоли, если что-то пойдет не так
            model.addAttribute("error", "Ошибка загрузки каталога: " + e.getMessage());
        }
        return "catalog";
    }
}