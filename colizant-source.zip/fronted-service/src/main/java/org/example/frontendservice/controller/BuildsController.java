package org.example.frontendservice.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/builds")
public class BuildsController {

    private final RestTemplate restTemplate;
    @Value("${gateway.url}")
    private String gatewayUrl;

    public BuildsController(RestTemplate restTemplate) { this.restTemplate = restTemplate; }

    @GetMapping
    public String listBuilds(HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) return "redirect:/login";

        try {
            Long userId = extractUserIdFromToken(token);
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);

            ResponseEntity<List> response = restTemplate.exchange(
                    gatewayUrl + "/api/builds?userId=" + userId,
                    HttpMethod.GET, new HttpEntity<>(headers), List.class);

            model.addAttribute("builds", response.getBody());
        } catch (Exception e) {
            model.addAttribute("error", "Ошибка загрузки сборок");
        }
        return "builds";
    }

    @PostMapping("/checkout/{id}")
    public String checkoutBuild(@PathVariable Long id, HttpSession session) {
        String token = (String) session.getAttribute("token");
        if (token == null) return "redirect:/login";

        try {
            Long userId = extractUserIdFromToken(token);
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);

            ResponseEntity<Map> buildResponse = restTemplate.exchange(
                    gatewayUrl + "/api/builds/" + id,
                    HttpMethod.GET, new HttpEntity<>(headers), Map.class);
            Map<String, Object> build = buildResponse.getBody();

            List<Map<String, Object>> buildItems = (List<Map<String, Object>>) build.get("items");
            List<Map<String, Object>> orderItems = new ArrayList<>();
            for (Map<String, Object> item : buildItems) {
                Map<String, Object> component = (Map<String, Object>) item.get("component");
                orderItems.add(Map.of(
                        "componentId", component.get("id"),
                        "quantity", item.get("quantity")
                ));
            }

            Map<String, Object> orderBody = Map.of("userId", userId, "items", orderItems);
            headers.setContentType(MediaType.APPLICATION_JSON);
            restTemplate.exchange(gatewayUrl + "/api/orders", HttpMethod.POST, new HttpEntity<>(orderBody, headers), Void.class);

            // Удаляем сборку после оформления
            restTemplate.exchange(gatewayUrl + "/api/builds/" + id, HttpMethod.DELETE, new HttpEntity<>(headers), Void.class);

            return "redirect:/orders?success";
        } catch (Exception e) {
            return "redirect:/builds?error=" + e.getMessage();
        }
    }

    private Long extractUserIdFromToken(String token) {
        String[] parts = token.split("\\.");
        String payload = new String(java.util.Base64.getUrlDecoder().decode(parts[1]));
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\"userId\":(\\d+)").matcher(payload);
        if (m.find()) return Long.parseLong(m.group(1));
        return 1L;
    }
}