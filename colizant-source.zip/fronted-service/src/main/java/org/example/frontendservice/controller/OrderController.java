package org.example.frontendservice.controller;

import jakarta.servlet.http.HttpSession;
import org.example.frontendservice.dto.OrderDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Controller
public class OrderController {
    private final RestTemplate restTemplate;
    @Value("${gateway.url}")
    private String gatewayUrl;

    public OrderController(RestTemplate restTemplate) { this.restTemplate = restTemplate; }

    @GetMapping("/orders")
    public String ordersPage(HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) return "redirect:/login";

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);
            ResponseEntity<OrderDto[]> response = restTemplate.exchange(
                    gatewayUrl + "/api/orders", HttpMethod.GET, new HttpEntity<>(headers), OrderDto[].class);

            model.addAttribute("orders", Arrays.asList(response.getBody()));
            model.addAttribute("isAdmin", session.getAttribute("roles") != null && session.getAttribute("roles").toString().contains("ROLE_ADMIN"));
        } catch (Exception e) {
            model.addAttribute("error", "Ошибка загрузки заказов");
        }
        return "orders";
    }

    @PostMapping("/orders/create")
    public String createOrder(@RequestParam Long componentId, @RequestParam Integer quantity, HttpSession session) {
        String token = (String) session.getAttribute("token");
        if (token == null) return "redirect:/login";

        try {
            // ВМЕСТО 1 ДОСТАЕМ ID ИЗ ТОКЕНА
            Long userId = extractUserIdFromToken(token);

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, Object> body = Map.of(
                    "userId", userId, // <-- ИСПОЛЬЗУЕМ РЕАЛЬНЫЙ ID
                    "items", List.of(Map.of("componentId", componentId, "quantity", quantity))
            );
            restTemplate.exchange(gatewayUrl + "/api/orders", HttpMethod.POST, new HttpEntity<>(body, headers), Void.class);
            return "redirect:/orders?success";
        } catch (Exception e) {
            return "redirect:/catalog?error";
        }
    }

    private Long extractUserIdFromToken(String token) {
        // Простейший парсинг JWT (без библиотек) — достаем payload
        String[] parts = token.split("\\.");
        String payload = new String(java.util.Base64.getUrlDecoder().decode(parts[1]));
        // payload выглядит как {"sub":"admin","userId":1,"roles":["ROLE_ADMIN"],...}
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\"userId\":(\\d+)").matcher(payload);
        if (m.find()) return Long.parseLong(m.group(1));
        return 1L; // Fallback
    }
}