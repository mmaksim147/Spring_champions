package org.example.frontendservice.config;

import jakarta.servlet.http.HttpSession;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class GlobalModelAdvice {
    @ModelAttribute
    public void auth(HttpSession session, Model model) {
        model.addAttribute("isAuthenticated", session.getAttribute("token") != null);
        Object roles = session.getAttribute("roles");
        model.addAttribute("isAdmin", roles != null && roles.toString().contains("ROLE_ADMIN"));
    }
}