package org.example.frontendservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import jakarta.servlet.http.HttpSession;
import org.example.frontendservice.dto.ProductDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Controller
public class BuilderController {

    private final RestTemplate restTemplate;

    @Value("${gateway.url}")
    private String gatewayUrl;

    public BuilderController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping("/builder")
    public String builderPage(HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) return "redirect:/login";

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);

            ResponseEntity<Map> response = restTemplate.exchange(
                    gatewayUrl + "/api/components?size=100",
                    HttpMethod.GET, new HttpEntity<>(headers), Map.class);

            if (response.getBody() != null && response.getBody().containsKey("content")) {
                List<Map<String, Object>> content = (List<Map<String, Object>>) response.getBody().get("content");
                ObjectMapper mapper = new ObjectMapper();
                mapper.registerModule(new JavaTimeModule());
                List<ProductDto> components = content.stream()
                        .map(item -> mapper.convertValue(item, ProductDto.class))
                        .toList();
                model.addAttribute("components", components);
            }
            model.addAttribute("username", session.getAttribute("username"));
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "Ошибка загрузки компонентов: " + e.getMessage());
        }
        return "builder";
    }

    @PostMapping("/builder/save")
    public String saveBuild(@RequestParam Long componentId,
                            @RequestParam(defaultValue = "1") Integer quantity,
                            @RequestParam String name,
                            HttpSession session) {
        String token = (String) session.getAttribute("token");
        if (token == null) return "redirect:/login";

        try {
            Long userId = extractUserIdFromToken(token);

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, Object> buildRequest = Map.of(
                    "userId", userId,
                    "name", name,
                    "items", List.of(Map.of("componentId", componentId, "quantity", quantity))
            );

            restTemplate.exchange(gatewayUrl + "/api/builds", HttpMethod.POST, new HttpEntity<>(buildRequest, headers), Void.class);
            return "redirect:/builds?success";
        } catch (Exception e) {
            return "redirect:/builder?error=" + e.getMessage();
        }
    }

    private Long extractUserIdFromToken(String token) {
        String[] parts = token.split("\\.");
        String payload = new String(java.util.Base64.getUrlDecoder().decode(parts[1]));
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\"userId\":(\\d+)").matcher(payload);
        if (m.find()) return Long.parseLong(m.group(1));
        return 1L;
    }
}