package org.example.frontendservice.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Controller
public class AdminController {
    private final RestTemplate restTemplate;
    @Value("${gateway.url}")
    private String gatewayUrl;

    public AdminController(RestTemplate restTemplate) { this.restTemplate = restTemplate; }

    // Главная страница админки (3 карточки)
    @GetMapping("/admin")
    public String adminPage(HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) return "redirect:/login";

        Object roles = session.getAttribute("roles");
        if (roles == null || !roles.toString().contains("ROLE_ADMIN")) {
            return "redirect:/catalog";
        }

        return "admin/index"; // Отдаем страницу с карточками
    }

    // Удаление пользователя
    @PostMapping("/admin/users/{id}/delete")
    public String deleteUser(@PathVariable Long id, HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) return "redirect:/login";

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);
            restTemplate.exchange(gatewayUrl + "/api/admin/users/" + id, HttpMethod.DELETE, new HttpEntity<>(headers), Void.class);
            return "redirect:/admin/users?success";
        } catch (Exception e) {
            return "redirect:/admin/users?error=" + e.getMessage();
        }
    }

    // Смена роли
    @PostMapping("/admin/users/{id}/role")
    public String changeRole(@PathVariable Long id, @RequestParam String role, HttpSession session) {
        String token = (String) session.getAttribute("token");
        if (token == null) return "redirect:/login";
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token);
            headers.setContentType(MediaType.APPLICATION_JSON);
            String fullRole = role.startsWith("ROLE_") ? role : "ROLE_" + role;
            Map<String, Object> body = Map.of("roles", List.of(fullRole));
            restTemplate.exchange(gatewayUrl + "/api/admin/users/" + id + "/roles", HttpMethod.PUT, new HttpEntity<>(body, headers), Void.class);
            return "redirect:/admin/users?success";
        } catch (Exception e) {
            return "redirect:/admin/users?error=" + e.getMessage();
        }
    }
}